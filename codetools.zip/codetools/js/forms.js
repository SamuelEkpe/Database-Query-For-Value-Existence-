function validate() {
    let a, b, c, filter;
    a = document.getElementById("Name");
    b = document.getElementById("phoneNumber");
    c = document.getElementById("Email");

    // filter = /^([a-zA-Z0-9_\.\-])+/@ (([a - zA - Z0 - 9\ - ]) + \.) + ([a - zA - Z0 - 9] { 2, 4 }) + $ / ; //Regular Expression to check email input pattern

    if (a.value == "") {
        alert("Enter Your Name");
        a.focus();
        return false;
    }
    if (!(isNaN(a.value))) {
        alert("Name must be a text");
        a.focus();
        return false;
    }

    if (b.value == "") {
        alert("Enter Phone Number");
        b.focus();
        return false;
    }
    if (isNaN(b.value)) {
        alert("Enter a valid phone Number");
        b.focus();
        return false;
    }
    if (b.value.length != 11) {
        alert("Invalid Phone Number");
        b.focus();
        return false;

    }
    if (c.value == "") {
        alert("Kindly Enter Your Email Address");
        c.focus();
        return false;
    }
    // if (!filter(c.value)) {
    //     alert("Invalid Email Address");
    //     c.focus();
    //     return false;
    // }
    alert("Welcome");
}